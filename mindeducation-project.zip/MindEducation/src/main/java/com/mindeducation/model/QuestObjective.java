package com.mindeducation.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "quest_objectives")
public class QuestObjective {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Description is required")
    @Column(columnDefinition = "TEXT", nullable = false)
    private String description;
    
    @NotNull(message = "Order number is required")
    @Column(name = "order_number", nullable = false)
    private Integer orderNumber;
    
    @Column(name = "objective_type")
    private String objectiveType; // COLLECT, BUILD, TALK_TO, FIND, SOLVE
    
    @Column(name = "target_value")
    private String targetValue;
    
    @Column(name = "current_value")
    private String currentValue = "0";
    
    @Column(name = "is_completed")
    private Boolean isCompleted = false;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "quest_id", nullable = false)
    private Quest quest;
    
    // Constructors
    public QuestObjective() {}
    
    public QuestObjective(String description, Integer orderNumber, String objectiveType, Quest quest) {
        this.description = description;
        this.orderNumber = orderNumber;
        this.objectiveType = objectiveType;
        this.quest = quest;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Integer getOrderNumber() {
        return orderNumber;
    }
    
    public void setOrderNumber(Integer orderNumber) {
        this.orderNumber = orderNumber;
    }
    
    public String getObjectiveType() {
        return objectiveType;
    }
    
    public void setObjectiveType(String objectiveType) {
        this.objectiveType = objectiveType;
    }
    
    public String getTargetValue() {
        return targetValue;
    }
    
    public void setTargetValue(String targetValue) {
        this.targetValue = targetValue;
    }
    
    public String getCurrentValue() {
        return currentValue;
    }
    
    public void setCurrentValue(String currentValue) {
        this.currentValue = currentValue;
    }
    
    public Boolean getIsCompleted() {
        return isCompleted;
    }
    
    public void setIsCompleted(Boolean isCompleted) {
        this.isCompleted = isCompleted;
    }
    
    public Quest getQuest() {
        return quest;
    }
    
    public void setQuest(Quest quest) {
        this.quest = quest;
    }
}