package com.mindeducation.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Max;

import java.util.List;

@Entity
@Table(name = "game_stages")
public class GameStage {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Title is required")
    @Column(nullable = false)
    private String title;
    
    @NotBlank(message = "Description is required")
    @Column(columnDefinition = "TEXT", nullable = false)
    private String description;
    
    @NotNull(message = "Order number is required")
    @Min(value = 1, message = "Order must be at least 1")
    @Column(name = "order_number", nullable = false)
    private Integer orderNumber;
    
    @NotBlank(message = "Educational content is required")
    @Column(name = "educational_content", columnDefinition = "TEXT", nullable = false)
    private String educationalContent;
    
    @Column(name = "learning_objectives", columnDefinition = "TEXT")
    private String learningObjectives;
    
    @Column(name = "difficulty_level")
    @Min(value = 1, message = "Difficulty must be at least 1")
    @Max(value = 5, message = "Difficulty must be at most 5")
    private Integer difficultyLevel = 1;
    
    @Column(name = "estimated_duration")
    private Integer estimatedDuration; // in minutes
    
    @Column(name = "is_completed")
    private Boolean isCompleted = false;
    
    @Column(name = "is_unlocked")
    private Boolean isUnlocked = false;
    
    @Column(name = "unlock_requirement")
    private String unlockRequirement;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "location_id", nullable = false)
    private Location location;
    
    @OneToMany(mappedBy = "gameStage", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Quest> quests;
    
    // Constructors
    public GameStage() {}
    
    public GameStage(String title, String description, Integer orderNumber, String educationalContent, Location location) {
        this.title = title;
        this.description = description;
        this.orderNumber = orderNumber;
        this.educationalContent = educationalContent;
        this.location = location;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Integer getOrderNumber() {
        return orderNumber;
    }
    
    public void setOrderNumber(Integer orderNumber) {
        this.orderNumber = orderNumber;
    }
    
    public String getEducationalContent() {
        return educationalContent;
    }
    
    public void setEducationalContent(String educationalContent) {
        this.educationalContent = educationalContent;
    }
    
    public String getLearningObjectives() {
        return learningObjectives;
    }
    
    public void setLearningObjectives(String learningObjectives) {
        this.learningObjectives = learningObjectives;
    }
    
    public Integer getDifficultyLevel() {
        return difficultyLevel;
    }
    
    public void setDifficultyLevel(Integer difficultyLevel) {
        this.difficultyLevel = difficultyLevel;
    }
    
    public Integer getEstimatedDuration() {
        return estimatedDuration;
    }
    
    public void setEstimatedDuration(Integer estimatedDuration) {
        this.estimatedDuration = estimatedDuration;
    }
    
    public Boolean getIsCompleted() {
        return isCompleted;
    }
    
    public void setIsCompleted(Boolean isCompleted) {
        this.isCompleted = isCompleted;
    }
    
    public Boolean getIsUnlocked() {
        return isUnlocked;
    }
    
    public void setIsUnlocked(Boolean isUnlocked) {
        this.isUnlocked = isUnlocked;
    }
    
    public String getUnlockRequirement() {
        return unlockRequirement;
    }
    
    public void setUnlockRequirement(String unlockRequirement) {
        this.unlockRequirement = unlockRequirement;
    }
    
    public Location getLocation() {
        return location;
    }
    
    public void setLocation(Location location) {
        this.location = location;
    }
    
    public List<Quest> getQuests() {
        return quests;
    }
    
    public void setQuests(List<Quest> quests) {
        this.quests = quests;
    }
}