package com.mindeducation.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.List;

@Entity
@Table(name = "locations")
public class Location {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Name is required")
    @Column(nullable = false)
    private String name;
    
    @NotBlank(message = "Description is required")
    @Column(columnDefinition = "TEXT", nullable = false)
    private String description;
    
    @Column(name = "historical_period")
    private String historicalPeriod;
    
    @Column(name = "image_url")
    private String imageUrl;
    
    @Column(name = "background_music")
    private String backgroundMusic;
    
    @Column(name = "is_unlocked")
    private Boolean isUnlocked = false;
    
    @Column(name = "unlock_requirement")
    private String unlockRequirement;
    
    @OneToMany(mappedBy = "location", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<GameStage> stages;
    
    // Constructors
    public Location() {}
    
    public Location(String name, String description, String historicalPeriod) {
        this.name = name;
        this.description = description;
        this.historicalPeriod = historicalPeriod;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getHistoricalPeriod() {
        return historicalPeriod;
    }
    
    public void setHistoricalPeriod(String historicalPeriod) {
        this.historicalPeriod = historicalPeriod;
    }
    
    public String getImageUrl() {
        return imageUrl;
    }
    
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
    
    public String getBackgroundMusic() {
        return backgroundMusic;
    }
    
    public void setBackgroundMusic(String backgroundMusic) {
        this.backgroundMusic = backgroundMusic;
    }
    
    public Boolean getIsUnlocked() {
        return isUnlocked;
    }
    
    public void setIsUnlocked(Boolean isUnlocked) {
        this.isUnlocked = isUnlocked;
    }
    
    public String getUnlockRequirement() {
        return unlockRequirement;
    }
    
    public void setUnlockRequirement(String unlockRequirement) {
        this.unlockRequirement = unlockRequirement;
    }
    
    public List<GameStage> getStages() {
        return stages;
    }
    
    public void setStages(List<GameStage> stages) {
        this.stages = stages;
    }
}