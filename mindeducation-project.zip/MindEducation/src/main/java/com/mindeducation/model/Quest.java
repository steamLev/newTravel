package com.mindeducation.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.List;

@Entity
@Table(name = "quests")
public class Quest {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Title is required")
    @Column(nullable = false)
    private String title;
    
    @NotBlank(message = "Description is required")
    @Column(columnDefinition = "TEXT", nullable = false)
    private String description;
    
    @NotNull(message = "Order number is required")
    @Column(name = "order_number", nullable = false)
    private Integer orderNumber;
    
    @Column(name = "quest_type")
    private String questType; // BUILDING, EXPLORATION, QUIZ, INTERACTION
    
    @Column(name = "target_object")
    private String targetObject;
    
    @Column(name = "required_items", columnDefinition = "TEXT")
    private String requiredItems; // JSON string
    
    @Column(name = "reward_items", columnDefinition = "TEXT")
    private String rewardItems; // JSON string
    
    @Column(name = "experience_points")
    private Integer experiencePoints = 0;
    
    @Column(name = "is_completed")
    private Boolean isCompleted = false;
    
    @Column(name = "is_optional")
    private Boolean isOptional = false;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "game_stage_id", nullable = false)
    private GameStage gameStage;
    
    @OneToMany(mappedBy = "quest", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<QuestObjective> objectives;
    
    // Constructors
    public Quest() {}
    
    public Quest(String title, String description, Integer orderNumber, String questType, GameStage gameStage) {
        this.title = title;
        this.description = description;
        this.orderNumber = orderNumber;
        this.questType = questType;
        this.gameStage = gameStage;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Integer getOrderNumber() {
        return orderNumber;
    }
    
    public void setOrderNumber(Integer orderNumber) {
        this.orderNumber = orderNumber;
    }
    
    public String getQuestType() {
        return questType;
    }
    
    public void setQuestType(String questType) {
        this.questType = questType;
    }
    
    public String getTargetObject() {
        return targetObject;
    }
    
    public void setTargetObject(String targetObject) {
        this.targetObject = targetObject;
    }
    
    public String getRequiredItems() {
        return requiredItems;
    }
    
    public void setRequiredItems(String requiredItems) {
        this.requiredItems = requiredItems;
    }
    
    public String getRewardItems() {
        return rewardItems;
    }
    
    public void setRewardItems(String rewardItems) {
        this.rewardItems = rewardItems;
    }
    
    public Integer getExperiencePoints() {
        return experiencePoints;
    }
    
    public void setExperiencePoints(Integer experiencePoints) {
        this.experiencePoints = experiencePoints;
    }
    
    public Boolean getIsCompleted() {
        return isCompleted;
    }
    
    public void setIsCompleted(Boolean isCompleted) {
        this.isCompleted = isCompleted;
    }
    
    public Boolean getIsOptional() {
        return isOptional;
    }
    
    public void setIsOptional(Boolean isOptional) {
        this.isOptional = isOptional;
    }
    
    public GameStage getGameStage() {
        return gameStage;
    }
    
    public void setGameStage(GameStage gameStage) {
        this.gameStage = gameStage;
    }
    
    public List<QuestObjective> getObjectives() {
        return objectives;
    }
    
    public void setObjectives(List<QuestObjective> objectives) {
        this.objectives = objectives;
    }
}