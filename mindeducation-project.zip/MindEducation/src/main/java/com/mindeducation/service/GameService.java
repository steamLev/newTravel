package com.mindeducation.service;

import com.mindeducation.model.*;
import com.mindeducation.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class GameService {
    
    @Autowired
    private CharacterRepository characterRepository;
    
    @Autowired
    private LocationRepository locationRepository;
    
    @Autowired
    private GameStageRepository gameStageRepository;
    
    @Autowired
    private QuestRepository questRepository;
    
    // Character methods
    public List<com.mindeducation.model.Character> getAllCharacters() {
        return characterRepository.findByIsActiveTrue();
    }
    
    public com.mindeducation.model.Character getCharacterById(Long id) {
        return characterRepository.findById(id).orElse(null);
    }
    
    public com.mindeducation.model.Character saveCharacter(com.mindeducation.model.Character character) {
        return characterRepository.save(character);
    }
    
    public void deleteCharacter(Long id) {
        characterRepository.deleteById(id);
    }
    
    // Location methods
    public List<Location> getAllLocations() {
        return locationRepository.findAllOrderByName();
    }
    
    public List<Location> getUnlockedLocations() {
        return locationRepository.findByIsUnlockedTrue();
    }
    
    public Location getLocationById(Long id) {
        return locationRepository.findById(id).orElse(null);
    }
    
    public Location saveLocation(Location location) {
        return locationRepository.save(location);
    }
    
    public void unlockLocation(Long locationId) {
        Optional<Location> locationOpt = locationRepository.findById(locationId);
        if (locationOpt.isPresent()) {
            Location location = locationOpt.get();
            location.setIsUnlocked(true);
            locationRepository.save(location);
        }
    }
    
    // GameStage methods
    public List<GameStage> getStagesByLocation(Long locationId) {
        Location location = getLocationById(locationId);
        if (location != null) {
            return gameStageRepository.findByLocationOrderByOrderNumber(location);
        }
        return List.of();
    }
    
    public List<GameStage> getUnlockedStagesByLocation(Long locationId) {
        Location location = getLocationById(locationId);
        if (location != null) {
            return gameStageRepository.findByLocationAndIsUnlockedTrueOrderByOrderNumber(location);
        }
        return List.of();
    }
    
    public GameStage getStageById(Long id) {
        return gameStageRepository.findById(id).orElse(null);
    }
    
    public GameStage saveStage(GameStage stage) {
        return gameStageRepository.save(stage);
    }
    
    public void completeStage(Long stageId) {
        Optional<GameStage> stageOpt = gameStageRepository.findById(stageId);
        if (stageOpt.isPresent()) {
            GameStage stage = stageOpt.get();
            stage.setIsCompleted(true);
            gameStageRepository.save(stage);
        }
    }
    
    // Quest methods
    public List<Quest> getQuestsByStage(Long stageId) {
        GameStage stage = getStageById(stageId);
        if (stage != null) {
            return questRepository.findByGameStageOrderByOrderNumber(stage);
        }
        return List.of();
    }
    
    public List<Quest> getIncompleteQuestsByStage(Long stageId) {
        GameStage stage = getStageById(stageId);
        if (stage != null) {
            return questRepository.findByGameStageAndIsCompletedFalseOrderByOrderNumber(stage);
        }
        return List.of();
    }
    
    public Quest getQuestById(Long id) {
        return questRepository.findById(id).orElse(null);
    }
    
    public Quest saveQuest(Quest quest) {
        return questRepository.save(quest);
    }
    
    public void completeQuest(Long questId) {
        Optional<Quest> questOpt = questRepository.findById(questId);
        if (questOpt.isPresent()) {
            Quest quest = questOpt.get();
            quest.setIsCompleted(true);
            questRepository.save(quest);
        }
    }
}