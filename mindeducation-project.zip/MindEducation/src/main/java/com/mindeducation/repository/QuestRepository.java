package com.mindeducation.repository;

import com.mindeducation.model.GameStage;
import com.mindeducation.model.Quest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuestRepository extends JpaRepository<Quest, Long> {
    
    List<Quest> findByGameStageOrderByOrderNumber(GameStage gameStage);
    
    List<Quest> findByGameStageAndIsCompletedFalseOrderByOrderNumber(GameStage gameStage);
    
    List<Quest> findByQuestType(String questType);
    
    @Query("SELECT q FROM Quest q WHERE q.gameStage = ?1 AND q.isOptional = false ORDER BY q.orderNumber")
    List<Quest> findRequiredQuestsByGameStage(GameStage gameStage);
}