package com.mindeducation.repository;

import com.mindeducation.model.GameStage;
import com.mindeducation.model.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GameStageRepository extends JpaRepository<GameStage, Long> {
    
    List<GameStage> findByLocationAndIsUnlockedTrueOrderByOrderNumber(Location location);
    
    List<GameStage> findByLocationOrderByOrderNumber(Location location);
    
    @Query("SELECT gs FROM GameStage gs WHERE gs.location = ?1 AND gs.isCompleted = false ORDER BY gs.orderNumber")
    List<GameStage> findIncompleteStagesByLocation(Location location);
    
    @Query("SELECT gs FROM GameStage gs WHERE gs.difficultyLevel <= ?1 ORDER BY gs.orderNumber")
    List<GameStage> findByDifficultyLevelLessThanEqual(Integer maxDifficulty);
}