package com.mindeducation.repository;

import com.mindeducation.model.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LocationRepository extends JpaRepository<Location, Long> {
    
    List<Location> findByIsUnlockedTrue();
    
    List<Location> findByHistoricalPeriod(String historicalPeriod);
    
    @Query("SELECT l FROM Location l ORDER BY l.name")
    List<Location> findAllOrderByName();
    
    List<Location> findByName(String name);
}