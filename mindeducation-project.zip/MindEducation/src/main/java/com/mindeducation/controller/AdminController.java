package com.mindeducation.controller;

import com.mindeducation.model.*;
import com.mindeducation.service.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {
    
    @Autowired
    private GameService gameService;
    
    @GetMapping("/")
    public String adminHome(Model model) {
        List<Location> locations = gameService.getAllLocations();
        List<com.mindeducation.model.Character> characters = gameService.getAllCharacters();
        
        model.addAttribute("locations", locations);
        model.addAttribute("characters", characters);
        
        return "admin/home";
    }
    
    // Character management
    @GetMapping("/characters")
    public String charactersList(Model model) {
        List<com.mindeducation.model.Character> characters = gameService.getAllCharacters();
        model.addAttribute("characters", characters);
        return "admin/characters/list";
    }
    
    @GetMapping("/characters/new")
    public String newCharacterForm(Model model) {
        model.addAttribute("character", new com.mindeducation.model.Character());
        return "admin/characters/form";
    }
    
    @PostMapping("/characters")
    public String saveCharacter(@ModelAttribute com.mindeducation.model.Character character, RedirectAttributes redirectAttributes) {
        gameService.saveCharacter(character);
        redirectAttributes.addFlashAttribute("message", "Character saved successfully!");
        return "redirect:/admin/characters";
    }
    
    @GetMapping("/characters/edit/{id}")
    public String editCharacterForm(@PathVariable Long id, Model model) {
        com.mindeducation.model.Character character = gameService.getCharacterById(id);
        if (character == null) {
            return "redirect:/admin/characters";
        }
        model.addAttribute("character", character);
        return "admin/characters/form";
    }
    
    // Location management
    @GetMapping("/locations")
    public String locationsList(Model model) {
        List<Location> locations = gameService.getAllLocations();
        model.addAttribute("locations", locations);
        return "admin/locations/list";
    }
    
    @GetMapping("/locations/new")
    public String newLocationForm(Model model) {
        model.addAttribute("location", new Location());
        return "admin/locations/form";
    }
    
    @PostMapping("/locations")
    public String saveLocation(@ModelAttribute Location location, RedirectAttributes redirectAttributes) {
        gameService.saveLocation(location);
        redirectAttributes.addFlashAttribute("message", "Location saved successfully!");
        return "redirect:/admin/locations";
    }
    
    @GetMapping("/locations/edit/{id}")
    public String editLocationForm(@PathVariable Long id, Model model) {
        Location location = gameService.getLocationById(id);
        if (location == null) {
            return "redirect:/admin/locations";
        }
        model.addAttribute("location", location);
        return "admin/locations/form";
    }
    
    // Stage management
    @GetMapping("/stages")
    public String stagesList(Model model) {
        List<Location> locations = gameService.getAllLocations();
        model.addAttribute("locations", locations);
        return "admin/stages/list";
    }
    
    @GetMapping("/stages/location/{locationId}")
    public String stagesByLocation(@PathVariable Long locationId, Model model) {
        Location location = gameService.getLocationById(locationId);
        List<GameStage> stages = gameService.getStagesByLocation(locationId);
        
        model.addAttribute("location", location);
        model.addAttribute("stages", stages);
        
        return "admin/stages/by-location";
    }
    
    @GetMapping("/stages/new")
    public String newStageForm(@RequestParam(required = false) Long locationId, Model model) {
        GameStage stage = new GameStage();
        if (locationId != null) {
            Location location = gameService.getLocationById(locationId);
            stage.setLocation(location);
        }
        
        List<Location> locations = gameService.getAllLocations();
        model.addAttribute("stage", stage);
        model.addAttribute("locations", locations);
        
        return "admin/stages/form";
    }
    
    @PostMapping("/stages")
    public String saveStage(@ModelAttribute GameStage stage, RedirectAttributes redirectAttributes) {
        gameService.saveStage(stage);
        redirectAttributes.addFlashAttribute("message", "Stage saved successfully!");
        return "redirect:/admin/stages/location/" + stage.getLocation().getId();
    }
    
    @GetMapping("/stages/edit/{id}")
    public String editStageForm(@PathVariable Long id, Model model) {
        GameStage stage = gameService.getStageById(id);
        if (stage == null) {
            return "redirect:/admin/stages";
        }
        
        List<Location> locations = gameService.getAllLocations();
        model.addAttribute("stage", stage);
        model.addAttribute("locations", locations);
        
        return "admin/stages/form";
    }
}