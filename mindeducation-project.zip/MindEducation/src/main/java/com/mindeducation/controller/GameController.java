package com.mindeducation.controller;

import com.mindeducation.model.*;
import com.mindeducation.service.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/game")
public class GameController {
    
    @Autowired
    private GameService gameService;
    
    @GetMapping("/")
    public String gameHome(Model model) {
        List<Location> locations = gameService.getUnlockedLocations();
        List<com.mindeducation.model.Character> characters = gameService.getAllCharacters();
        
        model.addAttribute("locations", locations);
        model.addAttribute("characters", characters);
        
        return "game/home";
    }
    
    @GetMapping("/location/{id}")
    public String locationDetails(@PathVariable Long id, Model model) {
        Location location = gameService.getLocationById(id);
        if (location == null) {
            return "redirect:/game/";
        }
        
        List<GameStage> stages = gameService.getStagesByLocation(id);
        
        model.addAttribute("location", location);
        model.addAttribute("stages", stages);
        
        return "game/location";
    }
    
    @GetMapping("/stage/{id}")
    public String stageDetails(@PathVariable Long id, Model model) {
        GameStage stage = gameService.getStageById(id);
        if (stage == null) {
            return "redirect:/game/";
        }
        
        List<Quest> quests = gameService.getQuestsByStage(id);
        
        model.addAttribute("stage", stage);
        model.addAttribute("quests", quests);
        
        return "game/stage";
    }
    
    @GetMapping("/quest/{id}")
    public String questDetails(@PathVariable Long id, Model model) {
        Quest quest = gameService.getQuestById(id);
        if (quest == null) {
            return "redirect:/game/";
        }
        
        model.addAttribute("quest", quest);
        
        return "game/quest";
    }
    
    @PostMapping("/complete-stage/{id}")
    @ResponseBody
    public String completeStage(@PathVariable Long id) {
        gameService.completeStage(id);
        return "Stage completed successfully";
    }
    
    @PostMapping("/complete-quest/{id}")
    @ResponseBody
    public String completeQuest(@PathVariable Long id) {
        gameService.completeQuest(id);
        return "Quest completed successfully";
    }
}