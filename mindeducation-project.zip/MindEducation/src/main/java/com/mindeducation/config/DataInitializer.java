package com.mindeducation.config;

import com.mindeducation.model.*;
import com.mindeducation.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private CharacterRepository characterRepository;
    
    @Autowired
    private LocationRepository locationRepository;
    
    @Autowired
    private GameStageRepository gameStageRepository;
    
    @Autowired
    private QuestRepository questRepository;

    @Override
    public void run(String... args) throws Exception {
        initializeCharacters();
        initializeLocations();
        initializeStages();
        initializeQuests();
    }

    private void initializeCharacters() {
        if (characterRepository.count() == 0) {
            com.mindeducation.model.Character boy = new com.mindeducation.model.Character();
            boy.setName("Marcus");
            boy.setAge(12);
            boy.setGender("Male");
            boy.setDescription("A curious 12-year-old boy who loves to explore and learn about ancient civilizations. He's brave and always ready for new adventures.");
            boy.setImageUrl("/images/characters/marcus.png");
            characterRepository.save(boy);

            com.mindeducation.model.Character girl = new com.mindeducation.model.Character();
            girl.setName("Livia");
            girl.setAge(6);
            girl.setGender("Female");
            girl.setDescription("A bright 6-year-old girl who is fascinated by stories and history. She's intelligent beyond her years and loves to ask questions.");
            girl.setImageUrl("/images/characters/livia.png");
            characterRepository.save(girl);
        }
    }

    private void initializeLocations() {
        if (locationRepository.count() == 0) {
            // Rome
            Location rome = new Location();
            rome.setName("Ancient Rome");
            rome.setDescription("The heart of the Roman Empire, where you'll explore the Colosseum, Roman Forum, and learn about Roman culture and government.");
            rome.setHistoricalPeriod("753 BC - 476 AD");
            rome.setImageUrl("/images/locations/rome.jpg");
            rome.setBackgroundMusic("/audio/rome-theme.mp3");
            rome.setIsUnlocked(true);
            locationRepository.save(rome);

            // Athens
            Location athens = new Location();
            athens.setName("Ancient Athens");
            athens.setDescription("The birthplace of democracy and philosophy, where you'll visit the Acropolis, Parthenon, and learn about Greek culture.");
            athens.setHistoricalPeriod("508 BC - 322 BC");
            athens.setImageUrl("/images/locations/athens.jpg");
            athens.setBackgroundMusic("/audio/athens-theme.mp3");
            athens.setIsUnlocked(false);
            athens.setUnlockRequirement("Complete all Rome stages");
            locationRepository.save(athens);

            // Crete
            Location crete = new Location();
            crete.setName("Ancient Crete");
            crete.setDescription("The mysterious island of the Minoans, where you'll explore the Palace of Knossos and learn about the earliest European civilization.");
            crete.setHistoricalPeriod("3000 BC - 1100 BC");
            crete.setImageUrl("/images/locations/crete.jpg");
            crete.setBackgroundMusic("/audio/crete-theme.mp3");
            crete.setIsUnlocked(false);
            crete.setUnlockRequirement("Complete all Athens stages");
            locationRepository.save(crete);
        }
    }

    private void initializeStages() {
        if (gameStageRepository.count() == 0) {
            Location rome = locationRepository.findByName("Ancient Rome").get(0);
            Location athens = locationRepository.findByName("Ancient Athens").get(0);
            Location crete = locationRepository.findByName("Ancient Crete").get(0);

            // Rome Stages
            GameStage romeStage1 = new GameStage();
            romeStage1.setTitle("Welcome to Rome");
            romeStage1.setDescription("Learn about the founding of Rome and its early history.");
            romeStage1.setOrderNumber(1);
            romeStage1.setEducationalContent("Rome was founded in 753 BC by Romulus and Remus. According to legend, they were raised by a she-wolf. Rome started as a small village and grew into a mighty empire.");
            romeStage1.setLearningObjectives("Understand the founding myths of Rome, Learn about early Roman society, Explore the geography of ancient Rome");
            romeStage1.setDifficultyLevel(1);
            romeStage1.setEstimatedDuration(15);
            romeStage1.setIsUnlocked(true);
            romeStage1.setLocation(rome);
            gameStageRepository.save(romeStage1);

            GameStage romeStage2 = new GameStage();
            romeStage2.setTitle("The Roman Republic");
            romeStage2.setDescription("Explore the Roman Republic and its government system.");
            romeStage2.setOrderNumber(2);
            romeStage2.setEducationalContent("The Roman Republic was established in 509 BC after the overthrow of the last Roman king. It featured a system of checks and balances with consuls, senators, and assemblies.");
            romeStage2.setLearningObjectives("Understand the Roman Republic government, Learn about Roman law and citizenship, Explore the concept of checks and balances");
            romeStage2.setDifficultyLevel(2);
            romeStage2.setEstimatedDuration(20);
            romeStage2.setIsUnlocked(false);
            romeStage2.setUnlockRequirement("Complete 'Welcome to Rome' stage");
            romeStage2.setLocation(rome);
            gameStageRepository.save(romeStage2);

            GameStage romeStage3 = new GameStage();
            romeStage3.setTitle("The Colosseum");
            romeStage3.setDescription("Build and explore the famous Colosseum.");
            romeStage3.setOrderNumber(3);
            romeStage3.setEducationalContent("The Colosseum, also known as the Flavian Amphitheatre, was built between 70-80 AD. It could hold up to 80,000 spectators and hosted gladiatorial games and other public spectacles.");
            romeStage3.setLearningObjectives("Learn about Roman architecture, Understand gladiatorial games, Explore Roman entertainment culture");
            romeStage3.setDifficultyLevel(3);
            romeStage3.setEstimatedDuration(25);
            romeStage3.setIsUnlocked(false);
            romeStage3.setUnlockRequirement("Complete 'The Roman Republic' stage");
            romeStage3.setLocation(rome);
            gameStageRepository.save(romeStage3);

            // Athens Stages
            GameStage athensStage1 = new GameStage();
            athensStage1.setTitle("The Birth of Democracy");
            athensStage1.setDescription("Learn about the origins of democracy in Athens.");
            athensStage1.setOrderNumber(1);
            athensStage1.setEducationalContent("Athens is considered the birthplace of democracy. The Athenian democracy was established around 508 BC by Cleisthenes. Citizens could participate directly in political decisions.");
            athensStage1.setLearningObjectives("Understand the concept of democracy, Learn about Athenian citizenship, Explore ancient Greek politics");
            athensStage1.setDifficultyLevel(2);
            athensStage1.setEstimatedDuration(18);
            athensStage1.setIsUnlocked(false);
            athensStage1.setUnlockRequirement("Complete all Rome stages");
            athensStage1.setLocation(athens);
            gameStageRepository.save(athensStage1);

            // Crete Stages
            GameStage creteStage1 = new GameStage();
            creteStage1.setTitle("The Minoan Civilization");
            creteStage1.setDescription("Discover the mysterious Minoan civilization on Crete.");
            creteStage1.setOrderNumber(1);
            creteStage1.setEducationalContent("The Minoans were the first advanced civilization in Europe, flourishing on Crete from around 3000 to 1100 BC. They were known for their advanced architecture and art.");
            creteStage1.setLearningObjectives("Learn about the Minoan civilization, Understand early European history, Explore ancient art and architecture");
            creteStage1.setDifficultyLevel(2);
            creteStage1.setEstimatedDuration(20);
            creteStage1.setIsUnlocked(false);
            creteStage1.setUnlockRequirement("Complete all Athens stages");
            creteStage1.setLocation(crete);
            gameStageRepository.save(creteStage1);
        }
    }

    private void initializeQuests() {
        if (questRepository.count() == 0) {
            GameStage romeStage1 = gameStageRepository.findByLocationOrderByOrderNumber(locationRepository.findByName("Ancient Rome").get(0)).get(0);

            // Rome Stage 1 Quests
            Quest quest1 = new Quest();
            quest1.setTitle("Meet Romulus and Remus");
            quest1.setDescription("Find the legendary founders of Rome and learn their story.");
            quest1.setOrderNumber(1);
            quest1.setQuestType("EXPLORATION");
            quest1.setTargetObject("Romulus and Remus statue");
            quest1.setExperiencePoints(50);
            quest1.setGameStage(romeStage1);
            questRepository.save(quest1);

            Quest quest2 = new Quest();
            quest2.setTitle("Build the First Hut");
            quest2.setDescription("Help build the first Roman hut using ancient techniques.");
            quest2.setOrderNumber(2);
            quest2.setQuestType("BUILDING");
            quest2.setTargetObject("Roman hut");
            quest2.setRequiredItems("Wood, Stone, Clay");
            quest2.setRewardItems("Building tools, Experience points");
            quest2.setExperiencePoints(75);
            quest2.setGameStage(romeStage1);
            questRepository.save(quest2);

            Quest quest3 = new Quest();
            quest3.setTitle("Roman Geography Quiz");
            quest3.setDescription("Test your knowledge about the geography of ancient Rome.");
            quest3.setOrderNumber(3);
            quest3.setQuestType("QUIZ");
            quest3.setTargetObject("Quiz completion");
            quest3.setExperiencePoints(100);
            quest3.setGameStage(romeStage1);
            questRepository.save(quest3);
        }
    }
}