// MindEducation Game JavaScript

class MindEducationGame {
    constructor() {
        this.currentCharacter = null;
        this.currentLocation = null;
        this.currentStage = null;
        this.gameState = {
            completedStages: [],
            completedQuests: [],
            unlockedLocations: [],
            experience: 0,
            level: 1
        };
        this.init();
    }

    init() {
        this.loadGameState();
        this.setupEventListeners();
        this.animateElements();
    }

    loadGameState() {
        const savedState = localStorage.getItem('mindEducationGameState');
        if (savedState) {
            this.gameState = { ...this.gameState, ...JSON.parse(savedState) };
        }
    }

    saveGameState() {
        localStorage.setItem('mindEducationGameState', JSON.stringify(this.gameState));
    }

    setupEventListeners() {
        // Character selection
        document.querySelectorAll('.character-card').forEach(card => {
            card.addEventListener('click', (e) => {
                this.selectCharacter(card);
            });
        });

        // Location selection
        document.querySelectorAll('.location-card').forEach(card => {
            card.addEventListener('click', (e) => {
                this.selectLocation(card);
            });
        });

        // Quest completion
        document.querySelectorAll('.quest-complete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.completeQuest(btn);
            });
        });

        // Stage completion
        document.querySelectorAll('.stage-complete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.completeStage(btn);
            });
        });
    }

    selectCharacter(card) {
        // Remove previous selection
        document.querySelectorAll('.character-card').forEach(c => {
            c.classList.remove('character-selected');
        });

        // Add selection to clicked card
        card.classList.add('character-selected');
        
        // Get character data
        const characterId = card.dataset.characterId;
        const characterName = card.querySelector('.card-title').textContent;
        
        this.currentCharacter = {
            id: characterId,
            name: characterName
        };

        this.showNotification(`Selected character: ${characterName}`, 'success');
        this.animateCharacterSelection(card);
    }

    selectLocation(card) {
        const locationId = card.dataset.locationId;
        const locationName = card.querySelector('.card-title').textContent;
        
        this.currentLocation = {
            id: locationId,
            name: locationName
        };

        this.showNotification(`Entering ${locationName}`, 'info');
        this.animateLocationSelection(card);
    }

    completeQuest(btn) {
        const questId = btn.dataset.questId;
        const questCard = btn.closest('.quest-card');
        
        // Add completion animation
        questCard.classList.add('quest-completed');
        
        // Update game state
        if (!this.gameState.completedQuests.includes(questId)) {
            this.gameState.completedQuests.push(questId);
            this.gameState.experience += 100; // Award experience
            this.saveGameState();
        }

        // Update UI
        btn.innerHTML = '<i class="fas fa-check me-2"></i>Completed';
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-success');
        btn.disabled = true;

        this.showNotification('Quest completed! +100 XP', 'success');
        this.checkLevelUp();
    }

    completeStage(btn) {
        const stageId = btn.dataset.stageId;
        const stageCard = btn.closest('.stage-card');
        
        // Add completion animation
        stageCard.classList.add('stage-completed');
        
        // Update game state
        if (!this.gameState.completedStages.includes(stageId)) {
            this.gameState.completedStages.push(stageId);
            this.gameState.experience += 500; // Award more experience for stage completion
            this.saveGameState();
        }

        // Update UI
        btn.innerHTML = '<i class="fas fa-check me-2"></i>Completed';
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-success');
        btn.disabled = true;

        this.showNotification('Stage completed! +500 XP', 'success');
        this.checkLevelUp();
    }

    checkLevelUp() {
        const newLevel = Math.floor(this.gameState.experience / 1000) + 1;
        if (newLevel > this.gameState.level) {
            this.gameState.level = newLevel;
            this.showNotification(`Level Up! You are now level ${newLevel}`, 'warning');
            this.animateLevelUp();
        }
    }

    animateElements() {
        // Animate cards on page load
        const cards = document.querySelectorAll('.card');
        cards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                card.style.transition = 'all 0.6s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });

        // Animate progress bars
        this.animateProgressBars();
    }

    animateProgressBars() {
        const progressBars = document.querySelectorAll('.stage-progress-bar');
        progressBars.forEach(bar => {
            const width = bar.dataset.width || '0%';
            bar.style.width = '0%';
            
            setTimeout(() => {
                bar.style.width = width;
            }, 500);
        });
    }

    animateCharacterSelection(card) {
        card.style.transform = 'scale(1.05)';
        setTimeout(() => {
            card.style.transform = 'scale(1)';
        }, 300);
    }

    animateLocationSelection(card) {
        card.classList.add('location-unlock');
        setTimeout(() => {
            card.classList.remove('location-unlock');
        }, 1000);
    }

    animateLevelUp() {
        // Create level up effect
        const levelUpDiv = document.createElement('div');
        levelUpDiv.innerHTML = '<i class="fas fa-star fa-3x text-warning"></i><br>LEVEL UP!';
        levelUpDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 30px;
            border-radius: 20px;
            text-align: center;
            z-index: 9999;
            animation: levelUpAnimation 2s ease-out forwards;
        `;
        
        document.body.appendChild(levelUpDiv);
        
        setTimeout(() => {
            document.body.removeChild(levelUpDiv);
        }, 2000);
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }

    // Game mechanics
    unlockLocation(locationId) {
        if (!this.gameState.unlockedLocations.includes(locationId)) {
            this.gameState.unlockedLocations.push(locationId);
            this.saveGameState();
            this.showNotification('New location unlocked!', 'success');
        }
    }

    getGameStats() {
        return {
            level: this.gameState.level,
            experience: this.gameState.experience,
            completedStages: this.gameState.completedStages.length,
            completedQuests: this.gameState.completedQuests.length,
            unlockedLocations: this.gameState.unlockedLocations.length
        };
    }

    // Educational content helpers
    showEducationalTip(content) {
        const tipDiv = document.createElement('div');
        tipDiv.className = 'alert alert-info position-fixed';
        tipDiv.style.cssText = 'bottom: 20px; left: 20px; z-index: 9999; max-width: 400px;';
        tipDiv.innerHTML = `
            <h6><i class="fas fa-lightbulb me-2"></i>Educational Tip</h6>
            <p>${content}</p>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(tipDiv);
        
        setTimeout(() => {
            if (tipDiv.parentNode) {
                tipDiv.parentNode.removeChild(tipDiv);
            }
        }, 5000);
    }
}

// Initialize game when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.game = new MindEducationGame();
    
    // Add CSS for level up animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes levelUpAnimation {
            0% { transform: translate(-50%, -50%) scale(0.5); opacity: 0; }
            50% { transform: translate(-50%, -50%) scale(1.2); opacity: 1; }
            100% { transform: translate(-50%, -50%) scale(1); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
});

// Utility functions
function showLoading(element) {
    element.innerHTML = '<div class="loading"></div> Loading...';
}

function hideLoading(element, originalContent) {
    element.innerHTML = originalContent;
}

// Quest and stage management
function startQuest(questId) {
    showNotification('Quest started! Good luck!', 'info');
    // Add quest-specific logic here
}

function startStage(stageId) {
    showNotification('Stage started! Begin your learning journey!', 'info');
    // Add stage-specific logic here
}

// Educational content display
function showHistoricalFact(fact) {
    const factDiv = document.createElement('div');
    factDiv.className = 'alert alert-warning position-fixed';
    factDiv.style.cssText = 'top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999; max-width: 500px;';
    factDiv.innerHTML = `
        <h5><i class="fas fa-scroll me-2"></i>Historical Fact</h5>
        <p>${fact}</p>
        <button type="button" class="btn btn-primary" onclick="this.parentElement.remove()">Got it!</button>
    `;
    
    document.body.appendChild(factDiv);
}